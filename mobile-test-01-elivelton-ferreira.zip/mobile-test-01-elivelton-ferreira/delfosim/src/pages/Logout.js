export default function Logout ({ navigation }) {

    const resultado = navigation.navigate("Login");
    return resultado

}